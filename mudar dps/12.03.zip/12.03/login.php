<form action="cadastrar.php" method="POST">

<h3>Cadastro</h3>

<label>Nome</label><br>
<input type="text" name="nome" placeholder="Informe o nome" required><br><br>

<label>Email</label><br>
<input type="email" name="email" placeholder="Informe o email" required><br><br>

<label>Senha</label><br>
<input type="password" name="senha" placeholder="Informe a senha" required><br><br>

<input type="submit" value="Cadastrar">

</form>