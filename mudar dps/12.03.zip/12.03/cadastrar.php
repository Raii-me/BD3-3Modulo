<?php

$nome = $_POST['nome'];
$email = $_POST['email'];
$senha = $_POST['senha'];

echo "O nome digitado foi....: $nome <br> ";
echo "O email digitado foi...: $email <br>";
echo "A senha digitado foi...: $senha ";

require 'Usuario.class.php';
$usuario = new Usuario();
$conecta = $usuario->conn();
if ($conecta) {
    $user = $usuario->checkEmail($email);
    if (!$user) {
        $user = $usuario->inserUser($nome, $email, $senha);
        if ($user) {
            echo "Usuario cadastrado com Sucesso!";
        } else {
            echo "Erro ao cadastar o Usuario!!!";
        }

    }else{
        echo "Usuario ja cadastrado";
    }

} else {
    echo "Banco indisponivel. Tente mais tarde ";
    exit();
}

?>