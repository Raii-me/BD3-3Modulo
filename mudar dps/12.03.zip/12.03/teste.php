<?php

require 'Usuario.class.php';

$usuario = new Usuario();
$conecta = $usuario->conn();

if ($conecta) {
    $user = $usuario->inserUser("Rai", "rai@gmail.com", 123);
    if ($user) {
        echo "<br><h1>Usuario cadastrado com Sucesso!";
    } else {
        echo "<br><h1>Erro ao cadastrar o Usuario cadastrado";
    }
} else {
    echo "<br><h1> erro ao conectar.";
}

?>